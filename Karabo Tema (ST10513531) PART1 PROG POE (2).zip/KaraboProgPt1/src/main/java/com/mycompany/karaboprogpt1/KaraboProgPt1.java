/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.karaboprogpt1;

/**
 *
 * @author TshiamoM
 */
public class KaraboProgPt1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
